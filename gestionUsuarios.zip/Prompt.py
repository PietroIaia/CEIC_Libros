#CEIC Libros
#Mensajes de alerta e informacion
#Desarrollado por Forward

from PyQt5.QtWidgets import *

class Prompt(QMessageBox):

    def  __init__(self, title, message):
        super().__init__()
        self.msg = QMessageBox()
        self.msg.setText(message)
        self.msg.setWindowTitle(title)

class ErrorPrompt(Prompt):

    def __init__(self, title, message):
        super().__init__(title, message)
        self.msg.setIcon(QMessageBox.Critical)
        self.msg.setStandardButtons(QMessageBox.Close)
        self.msg.exec_()

class InfoPrompt(Prompt):

    def __init__(self, title, message):
        super().__init__(title, message)
        self.msg.setIcon(QMessageBox.Information)
        self.msg.setStandardButtons(QMessageBox.Ok)
        self.msg.exec_()

class ConfirmPrompt(Prompt):

    def __init__(self, title, message):
        super().__init__(title, message)
        self.msg.setIcon(QMessageBox.Warning)
        self.msg.setStandardButtons(QMessageBox.Ok)
        self.msg.exec_()
        
